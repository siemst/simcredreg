//Author: Tobias Siems <tobias.siems@yahoo.com>
#include"inference.h"
#include"declarations.h"
#include"random_stuff.h"
#include"my_time.h"

#include<random>
#include<iostream>
#include<unordered_set>
#include<cmath>


#include<Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
List produce_samples(const probvec &data, csr sample_size, csr model, cdr d=0.0005){
  inference_t *inference=NULL;
  switch (model) {
  case gauss_known_var_jump_prob:
    inference=inference_t::get_jump_inference(data, gauss_known_var_jump_prob, d);
    break;
  case laplace_known_var_jump_prob:
    inference=inference_t::get_jump_inference(data, laplace_known_var_jump_prob, d);
    break;
  case gauss_known_mean_fixed_cp:
    inference=inference_t::get_fixed_cp_inference(data, gauss_known_mean_fixed_cp, d);
    break;
  case geometric_fixed_cp:
    inference=inference_t::get_fixed_cp_inference(data, geometric_fixed_cp, d);
    break;
  }
  inference->kalman();
  std::vector<std::pair<double, indexvec>> s=inference->sample_and_likelihood(sample_size);
  std::vector<indexvec> samples;
  probvec likelihoods;
  for(auto it=s.cbegin(); it!= s.cend(); it++){
    likelihoods<<it->first;
    samples<<it->second;
  }
  return List::create(likelihoods, samples);
}


inference_t *inference_t::get_jump_inference(const probvec &data, model_type m_type, cdr jump_prob){
  inference_t *inference=NULL;
  switch(m_type){
  case gauss_known_var_jump_prob:
    inference = new inference_gauss_known_var_jump_prob(data, jump_prob, 1, 1);
    break;
  case laplace_known_var_jump_prob:
    inference = new inference_laplace_known_var_jump_prob(data, jump_prob, 5, 0);
    break;
  default:
    std::cout<<"can't process this model!"<<std::endl;
  return 0;
  }
  return inference;
}

inference_t *inference_t::get_fixed_cp_inference(const probvec &data, model_type m_type, csr changepoint_count){
  inference_t *inference=NULL;
  switch(m_type){
  case gauss_known_mean_fixed_cp:
    inference = new inference_gauss_known_mean_fixed_cp(data, changepoint_count, 1, 0.0001);
    break;
  case geometric_fixed_cp:
    inference = new inference_geometric_fixed_cp(data, changepoint_count, 1, 1);
    break;
  default:
    std::cout<<"can't process this model!"<<std::endl;
  return 0;
  }
  return inference;
}


size_t inference_t::sample_weights_of_mixture(const std::vector<triple> &v){  //sample from the weights of a mixture in reverse order
  double d=sample_uniform(0,1);
  int i=0;
  for(auto it=v.crbegin(); it!=v.crend(); it++){
    d-=it->q;
    if(d<0)
      return i;
    i++;
  }
  return i-1;
}

size_t inference_t::sample_weights_of_mixture(const probvec &v){
  double d=sample_uniform(0,1);
  int i=0;
  for(auto it=v.crbegin(); it!=v.crend(); it++){
    d-=(*it);
    if(d<0)
      return i;
    i++;
  }
  return i-1;
}
//##########################################################################################################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
inference_fixed_cp::inference_fixed_cp(csr number_of_changepoints): number_of_changepoints(number_of_changepoints){
}
std::vector<std::pair<double, indexvec> > inference_fixed_cp::sample_and_likelihood(csr sample_size){
  std::cout<<"sample_and_likelihood started"<<std::endl;
  std::cout<<sample_size<<" samples!"<<std::endl;
  std::vector<std::pair<double, indexvec> > samples;
  for(size_t i=0;i<sample_size;i++){                //sample "number_of_samples" times changepoint locations
    auto it=smoothy.rbegin();
    indexvec changepoints;
    double loglikelihood=0;
    size_t c=number_of_changepoints;
    while(true){
      csr r=sample_weights_of_mixture(it->operator[](c));            //get the next changepoint location in reverse order, starting at the reverse beginning
      //the index of the triple denotes how long the last changepoint is away
      loglikelihood+=log((it->operator[](c).rbegin()+r)->q);        //compute the loglikelihood of the sample
      it+=r+1;
      if(it==smoothy.crend())
        break;
      changepoints<<index_of_reverse_iterator(smoothy,it-1);  //push the changepoint location
      c--;
    }
    samples<<std::make_pair(loglikelihood, changepoints);       //save a pair: the likelihood of the sample and the changepoint locations
  }
  return samples;
  std::cout<<"Done"<<std::endl;
}
void inference_fixed_cp::kalman(){
  std::cout<<"Performing Kalman Recursion"<<std::endl;
  cdr y=data[0];
  std::vector<triplevec> fresh(number_of_changepoints+1, triplevec(1, jump_posterior(0,y)));
  fresh[0][0]=jump_posterior(1,y);
  smoothy.clear();
  smoothy<<fresh;
  for(size_t i=1; i<data_size; i++){                //generate one mixture per data point recursively using the previous mixture
    cdr y=data[i];
    std::vector<triplevec> &old=smoothy[i-1];
    fresh.clear();
    double denom=0;
    triple jump_t(0,1,1);
    probvec v;
    for(size_t k=0; k <= number_of_changepoints; k++){
      triplevec vt;
      double d=0;
      for(auto it=old[k].cbegin(); it != old[k].cend(); it++){
        triple t=kalman_posterior(*it, jump_prior(k, i), y);
        d+=it->q;
        denom+=t.q;
        vt<<t;
      }
      v<<d;
      for(auto it=old[k].begin(); it != old[k].end(); it++){
        if(d != 0)
          it->q=it->q/d;
      }
      vt<<jump_t;
      denom+=jump_t.q;
      jump_t=jump_posterior(d*jump_prior(k, i), y);                            //the mixture component and weight in case of a changepoint
      fresh<<vt;
    }
    kth_jump_prob<<v;
    for(auto it = fresh.begin(); it!=fresh.end(); it++){                                        //normalize the mixture weights
      for(auto it2=it->begin(); it2!=it->end(); it2++)
        it2->q=it2->q/denom;
    }
    smoothy<<fresh;
  }
  probvec v(number_of_changepoints, 0);
  v<<1.0;
  kth_jump_prob<<v;
  std::cout<<"Done"<<std::endl;
}
//##########################################################################################################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
inference_jump_prob::inference_jump_prob(cdr jump_prob): jump_prob(jump_prob){
}
std::vector<std::pair<double, indexvec> > inference_jump_prob::sample_and_likelihood(csr sample_size){
  std::cout<<"sample_and_likelihood started"<<std::endl;
  std::cout<<sample_size<<" samples!"<<std::endl;
  std::vector<std::pair<double, indexvec> > samples;
  for(size_t i=0;i<sample_size;i++){                //sample "number_of_samples" times changepoint locations
    auto it=smoothy.rbegin();
    indexvec changepoints;
    double loglikelihood=0;
    while(true){
      csr r=sample_weights_of_mixture(*it);           //get the next changepoint location in reverse order, starting at the reverse beginning
      //the index of the triple denotes how long the last changepoint is away
      loglikelihood+=log((it->rbegin()+r)->q);        //compute the loglikelihood of the sample
      it+=r+1;
      if(it==smoothy.crend())
        break;
      changepoints<<index_of_reverse_iterator(smoothy,it-1);  //push the changepoint location
    }
    //                std::cout<<changepoints.size()<<std::endl;
    samples<<std::make_pair(loglikelihood, changepoints);       //save a pair: the likelihood of the sample and the changepoint locations
  }
  std::cout<<"Done"<<std::endl;
  return samples;
}
void inference_jump_prob::kalman(){
  std::cout<<"Performing Kalman Recursion"<<std::endl;
  auto it=data.cbegin();
  cdr y=(*it);
  smoothy.clear();
  triplevec fresh;
  triple t=jump_posterior(1, y);
  t.q=1;
  fresh<<t;
  smoothy<<fresh;
  it++;
  for(;it!=data.cend(); it++){                //generate one mixture per data point recursively using the previous mixture
    cdr y=(*it);
    const triplevec old=fresh;
    fresh.clear();
    double denom=0;
    for(auto it = old.begin(); it!=old.end(); it++){
      triple t=kalman_posterior(*it, y);
      denom+=t.q;
      fresh<<t;
    }
    triple t=jump_posterior(jump_prob, y);                           //the mixture component and weight in case of a changepoint
    denom+=t.q;
    fresh<<t;
    for(auto it = fresh.begin(); it!=fresh.end(); it++) //normalize the mixture weights
      it->q=it->q/denom;
    smoothy<<fresh;
  }
  std::cout<<"Done"<<std::endl;
}
double inference_fixed_cp::jump_prior(csr changepoint, csr timepoint){
  if(changepoint > timepoint)
    return 0;
  if(data_size-timepoint < number_of_changepoints-changepoint)
    return 0;
  if(changepoint > number_of_changepoints)
    return 0;
  return double(number_of_changepoints-changepoint)/(data_size-timepoint);
}
//##########################################################################################################################################################
//##########################################################################################################################################################
//###############################################################                      #####################################################################
//############################################################### Gauss known variance #####################################################################
//###############################################################                      #####################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
inference_gauss_known_var_jump_prob::inference_gauss_known_var_jump_prob(const probvec &data, cdr jump_prob, cdr teta, cdr delta)
  :inference_t(data, teta, delta), inference_jump_prob(jump_prob){
  data_size=data.size();
  std::cout<<data_size<<" Datapoints."<<std::endl;
  std::cout<<"Gauss with known variance and given jump probability: "<<jump_prob<<std::endl;
}
triple inference_gauss_known_var_jump_prob::jump_posterior(cdr q, cdr y){
  static cdr sd=25;
  return triple(q*phi(y,0,teta+sd), sd*y/(sd+teta), teta*sd/(teta+sd));
}
triple inference_gauss_known_var_jump_prob::kalman_posterior(const triple &old_t, cdr y){
  triple t;
  t.q=old_t.q*(1-jump_prob)*phi(y,old_t.m,old_t.v+teta);      //update step
  t.m=(old_t.m*teta+y*old_t.v)/(teta+old_t.v);                //update step (kalman filter like)
  t.v=(old_t.v*teta)/(old_t.v+teta);                          //update step (kalman filter like)
  return t;
}
//##########################################################################################################################################################
//##########################################################################################################################################################
//###############################################################           ################################################################################
//############################################################### Dow Jones ################################################################################
//###############################################################           ################################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
inference_gauss_known_mean_fixed_cp::inference_gauss_known_mean_fixed_cp(const probvec &data, csr number_of_changepoints, cdr teta, cdr delta)
  :inference_t(data, teta, delta), inference_fixed_cp(number_of_changepoints){
  data_size=data.size();
  std::cout<<data_size<<" Datapoints."<<std::endl;
  std::cout<<"Gauss with known mean and fixed cp: "<<number_of_changepoints<<" teta:"<<teta<<" delta:"<<delta<<std::endl;
}
triple inference_gauss_known_mean_fixed_cp::jump_posterior(cdr q, cdr y){
  return triple(q*student(y, 2*teta, delta/teta),0.5+teta,0.5*y*y+delta);
}

triple inference_gauss_known_mean_fixed_cp::kalman_posterior(const triple &old_t, cdr q, cdr y){
  triple t;
  t.q=old_t.q*(1-q)*student(y, 2*old_t.m, old_t.v/old_t.m);                           //update step
  t.m=0.5+old_t.m;                                                                    //update step (kalman filter like)
  t.v=0.5*y*y+old_t.v;                                                                //update step (kalman filter like)r lik
  return t;
}
//##########################################################################################################################################################
//##########################################################################################################################################################
//###############################################################           ################################################################################
//############################################################### Coal Mine ################################################################################
//###############################################################           ################################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
inference_geometric_fixed_cp::inference_geometric_fixed_cp(const probvec &data, csr number_of_changepoints, cdr teta, cdr delta)
  :inference_t(data, teta, delta), inference_fixed_cp(number_of_changepoints){
  data_size=data.size();
  std::cout<<data_size<<" Datapoints."<<std::endl;
  std::cout<<"Geometric with given changepoint number: "<<number_of_changepoints<<std::endl;
}
triple inference_geometric_fixed_cp::jump_posterior(cdr q, cdr y){
  double e=0;
  for(size_t k=1; k<y; k++)
    e+=log1p(-teta/(delta+k));
  e+=log1p(-(delta+y)/(teta+delta+y));
  return triple(q*exp(e),1+teta, delta+y-1);
}

triple inference_geometric_fixed_cp::kalman_posterior(const triple &old_t, cdr q, cdr y){
  triple t;
  double e=0;
  for(size_t k=1; k<y; k++)
    e+=log1p(-old_t.m/(old_t.v+k));
  e+=log1p(-(old_t.v+y)/(old_t.m+old_t.v+y));
  t.q=old_t.q*(1-q)*exp(e);                                                         //update step
  t.m=old_t.m+1;                                                                //update step (kalman filter like)
  t.v=old_t.v+y-1;
  return t;
}
//##########################################################################################################################################################
//##########################################################################################################################################################
//#############################################################              Well Log           ############################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
inference_laplace_known_var_jump_prob::inference_laplace_known_var_jump_prob(const probvec &data, cdr jump_prob, cdr teta, cdr delta)
  : inference_t(data, teta, delta), jump_prob(jump_prob){
  data_size=data.size();
  std::cout<<data_size<<" Datapoints."<<std::endl;
  std::cout<<"Laplace with known var and given jump probability: "<<jump_prob<<std::endl;
}
double inference_laplace_known_var_jump_prob::get_q(cdr sum_y, const probmultiset &l){
  double d=sum_y;
  cir n=l.size();
  auto it=l.cbegin();
  double y=(*it);
  double sum=std::exp(d+n*y)/n;
  for(int k=0; k<n-1; k++){
    cdr y1=(*it);
    it++;
    cdr y2=(*it);
    d+=2*y1;
    cir denominator=2*(k+1)-n;
    if(denominator==0)
      sum+=std::exp(d)*(y2-y1);
    else
      sum+=(std::exp(d-denominator*y1)-std::exp(d-denominator*y2))/denominator;
  }
  y=(*it);
  d+=2*y;
  sum+=std::exp(d-n*y)/n;
  return sum;
}

double inference_laplace_known_var_jump_prob::get_q_with_Z(cdr sum_y, const probmultiset &l, cdr Z){
  double d=sum_y;
  cir n=l.size();
  auto it=l.cbegin();
  double y=(*it);
  double sum=std::exp(d+n*y+Z)/n;
  for(int k=0; k<n-1; k++){
    cdr y1=(*it);
    it++;
    cdr y2=(*it);
    d+=2*y1;
    cir denominator=2*(k+1)-n;
    if(denominator==0)
      sum+=std::exp(d+Z)*(y2-y1);
    else
      sum+=(std::exp(d-denominator*y1+Z)-std::exp(d-denominator*y2+Z))/denominator;
  }
  y=(*it);
  d+=2*y;
  sum+=std::exp(d-n*y+Z)/n;
  return sum;
}

void inference_laplace_known_var_jump_prob::kalman(){
  std::cout<<"Performing Kalman Recursion with negative binomial"<<std::endl;
  csr r=5;
  smoothy.clear();
  std::cout<<"r: "<<r<<" jump_prob: "<<jump_prob<<std::endl;
  smoothy<<(probvec()<<1.);
  probvec y_vec;
  cdr log_2=log(2);
  y_vec<<0.;
  my_time time;
  double loglikelihood=0;
  for(size_t i=1; i<data_size-1; i++){                //generate one mixture per data point recursively using the previous mixture
    if(i%100==0)
      std::cout<<i<<" of "<<data_size<<std::endl;
    probmultiset l;
    double sum=0;
    std::list<probmultiset::const_iterator> l_help;
    for(size_t j=0; j<=i; j++){
      cdr y=data[j];
      sum-=y;
      l_help<<l.insert(y);
    }
    smoothy<<probvec();
    probvec &fresh=(*smoothy.rbegin());
    loglikelihood+=y_vec[i-1];
    double temp_loglikelihood=loglikelihood;
    cdr prob=get_q_with_Z(sum, l, log(neg_binom_inverse_cdf(r, jump_prob, i))-temp_loglikelihood-(i+1)*log_2);
    //        std::cout<<", "<<neg_binom_cdf_comp(r, new_jump_prob, i)<<"  "<<log_denom_boarder;
    double denom=prob;
    fresh<<prob;
    for(size_t j=1; j<=i; j++){
      sum+=data[j-1];
      l.erase((*l_help.cbegin()));
      l_help.erase(l_help.cbegin());
      temp_loglikelihood-=y_vec[j-1];
      csr m=i-j;
      double prob=0;
      cdr d=neg_binom_pdf(r, jump_prob, m);
      if(d>eps)
        prob=get_q_with_Z(sum, l, log(d)-temp_loglikelihood-m*log_2);
      //            std::cout<<d<<", "<<temp_loglikelihood<<", "<<prob<<", "<<denom<<"     ";
      denom+=prob;
      fresh<<prob;
    }
    y_vec<<log(denom);
    fresh/=denom;
    //        std::cout<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl<<std::endl;
  }
  probmultiset l;
  double sum=0;
  std::list<probmultiset::const_iterator> l_help;
  for(size_t j=0; j<data_size; j++){
    cdr y=data[j];
    sum-=y;
    l_help<<l.insert(y);
  }
  smoothy<<probvec();
  probvec &fresh=(*smoothy.rbegin());
  loglikelihood+=y_vec[data_size-1];
  cdr prob=get_q_with_Z(sum, l, log(neg_binom_inverse_cdf(r, jump_prob, data_size))-loglikelihood-data_size*log_2);
  //        std::cout<<", "<<neg_binom_cdf_comp(r, new_jump_prob, i)<<"  "<<log_denom_boarder;
  double denom=prob;
  fresh<<prob;
  for(size_t j=1; j<data_size; j++){
    sum+=data[j-1];
    l.erase((*l_help.cbegin()));
    l_help.erase(l_help.cbegin());
    loglikelihood-=y_vec[j-1];
    csr m=data_size-j;
    double prob=0;
    cdr d=neg_binom_inverse_cdf(r, jump_prob, m);
    if(d>eps)
      prob=get_q_with_Z(sum, l, log(d)-loglikelihood-m*log_2);
    //            std::cout<<d<<", "<<temp_loglikelihood<<", "<<prob<<", "<<denom<<"     ";
    denom+=prob;
    fresh<<prob;
  }
  y_vec<<log(denom);
  fresh/=denom;
  time.time_since_start();
  std::cout<<"Done"<<std::endl;
}
std::vector<std::pair<double, indexvec> > inference_laplace_known_var_jump_prob::sample_and_likelihood(csr sample_size){
  std::cout<<"sample_and_likelihood started"<<std::endl;
  std::cout<<sample_size<<" samples!"<<std::endl;
  std::vector<std::pair<double, indexvec> > samples;
  for(size_t i=0;i<sample_size;i++){                //sample "number_of_samples" times changepoint locations
    auto it=smoothy.rbegin();
    indexvec changepoints;
    double loglikelihood=0;
    while(true){
      csr r=sample_weights_of_mixture(*it);           //get the next changepoint location in reverse order, starting at the reverse beginning
      //the index of the triple denotes how long the last changepoint is away
      loglikelihood+=log(*(it->rbegin()+r));        //compute the loglikelihood of the sample
      it+=r+1;
      if(it==smoothy.crend())
        break;
      changepoints<<index_of_reverse_iterator(smoothy,it-1);  //push the changepoint location
    }
    //        std::cout<<changepoints<<std::endl;
    samples<<std::make_pair(loglikelihood, changepoints);       //save a pair: the likelihood of the sample and the changepoint locations
  }
  std::cout<<"Done"<<std::endl;
  return samples;
}
