.get_alpha<- function(i, number_of_alphas){
  return (i/(number_of_alphas+1))
}
#' Get credible regions according to greedy
#'
#' Extract a credible region fom the greedy output with respect to a given alpha
#'
#' @param greedy_region The output of greedy
#' @param sample_size The number of samples
#' @param alphas The alpha value the credible region should be computed for
#' @examples
#'
#' #produce samples
#' s=produce_samples(gaussian_jumping_means, 100000, 0, 3/550)
#' #compute credible regions
#' cr=greedyHeuristic(length(gaussian_jumping_means), s[[2]])
#' #get credible region for  alpha=0.6
#' g=extractCredibleRegionFromGreedyOutput(cr, length(s[[2]]), 0.6)
#'
#' @author Tobias Siems <tobias.siems@yahoo.com>
extractCredibleRegionFromGreedyOutput <-function(greedy_region, sample_size, alpha){
  drop_size=alpha*sample_size
  counter=1;
  droped=0;
  while(counter<length(greedy_region[[1]])+1){
    droped=droped+greedy_region[[2]][counter]
    if(droped>drop_size)
      break
    counter=counter+1
  }
  if(counter==length(greedy_region[[1]])+1)
    return (c())
  return (greedy_region[[1]][(counter):length(greedy_region[[1]])])
}

#' Joined highest density regions
#'
#' Compute joined confidence sets using stepR. Will only work for a Gaussian change in mean dataset.
#'
#' @param data A dataset
#' @param number_of_alphas The number of alphas the confidence intervals should be computed for
#' @examples
#'
#' ##Gaussian jumping mean example
#' #compute joined confidence sets with stepR
#' cf=jCFSmuce(gaussian_jumping_means, 29)
#' #draw the data and the joined confidence sets
#' drawDataAndCredibleRegions(gaussian_jumping_means, cf, "Gaussian change in mean")
#'
#' ##Well-Log Example
#' #compute joined confidence sets with stepR
#' cf=jCFSmuce(well_log, 29)
#' #draw the data and the joined confidence sets
#' drawDataAndCredibleRegions(well_log, cf, "Well-Log")
#' @author Tobias Siems <tobias.siems@yahoo.com>
jCFSmuce <- function(data, number_of_alphas){  #n is the number of confidence sets
  require(stepR)
  k=list()
  for(i in 1:(number_of_alphas)){
    a=.get_alpha(i, number_of_alphas)
    b <- bounds(data, family="gauss", alpha=a, param=1)
    # fit step function
    sb <- stepbound(data, b, family="gauss", jumpint = TRUE)
    j=jumpint(sb)
    k=append(k,list(cbind(j[,3],j[,4])))
  }
  confidence_regions=list()
  for(i in 1:length(k)){
    region=c();
    for(j in 1:length(k[[i]][,1])){
      region=c(region,k[[i]][j,1]:k[[i]][j,2])
    }
    confidence_regions=append(confidence_regions, list(region[1:(length(region)-1)]))
  }
  d=k
  reg=list()
  for(i in 1:length(d)){
    myreg=c();
    for(j in 1:length(d[[i]][,1])){
      myreg=c(myreg,d[[i]][j,1]:d[[i]][j,2])
    }
    reg=append(reg, list(myreg))
  }
  return(reg)
}





#' Marginal changepoint probabilities
#'
#' Compute marginal changepoint probabilities and Bonferroni sets
#'
#' @param samples Changepoint samples
#' @param data_size Size of the dataset from which the sample where drawn
#' @param number_of_alphas The number of alphas the confidence intervals should be computed for
#' @return Two lists, first the regions derived by marginal changepoint probabilities and second the Bonferroni sets
#' @examples
#'
#' #produce samples
#' s=produceSamples(dow_jones, 100000, 2, 5)
#'
#' #get marginal changepoint probabilities and Bonferroni sets
#' m=marginals(s[[2]], length(dow_jones), 29)
#'
#' #produce plot
#' par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
#' drawData(dow_jones, "Dow Jones")
#' drawCredibleRegions(m[[2]], length(dow_jones), "gray")
#' addCredibleRegions(m[[1]], length(dow_jones), color="black")
#' @author Tobias Siems <tobias.siems@yahoo.com>
marginals <- function(samples, data_size, number_of_alphas){
  marginals=rep(0, data_size)
  sample_size=length(samples)
  for(i in 1:sample_size){
    for(j in 1:length(samples[[i]]))
      marginals[samples[[i]][j]]=marginals[samples[[i]][j]]+1;
  }
  for(i in 1:data_size)
    marginals[i]=marginals[i]/sample_size
  marginal_regions=c()
  bonferroni_regions=c()
  for(i in  1:number_of_alphas){
    marginal_region=c()
    bonferroni_region=c()
    alpha=.get_alpha(i ,number_of_alphas)
    for(j in 1:data_size){
      if(marginals[j]>alpha/data_size)
        bonferroni_region=c(bonferroni_region, j)
      if(marginals[j]>alpha)
        marginal_region=c(marginal_region, j)
    }
    marginal_regions=c(marginal_regions, list(marginal_region))
    bonferroni_regions=c(bonferroni_regions, list(bonferroni_region))
  }
  return (list(marginal_regions, bonferroni_regions))
}

#' Greedy Heuristic
#'
#' Fast implemmentation of the greedy heuristic
#'
#' @param data_size Size of the dataset from which the sample where drawn
#' @param samples Changepoint samples
#' @return Two lists: the timepoints that where removed iteratively,
#' the number of samples that where removed in order to remove the timepoints
#'
#' @examples
#' ##Greedy for the Gaussian change in mean dataset
#' #produce samples
#' s=produce_samples(gaussian_jumping_means, 100000, 0, 3/550)
#' #compute credible regions
#' cr=greedyHeuristic(length(gaussian_jumping_means), s[[2]])
#' #Draw
#' drawDataAndGreedyRegions(gaussian_jumping_means, cr, length(s[[2]]), "Gaussian change in mean")
#'
#' ##Greedy for the Dow_Jones dataset
#' #produce samples
#' s=produce_samples(dow_jones, 100000, 2, 5)
#' #compute credible regions
#' cr=greedyHeuristic(length(dow_jones), s[[2]])
#' #Draw
#' drawDataAndGreedyRegions(dow_jones, cr, length(s[[2]]), "Dow Jones")
#'
#' ##Greedy for the Laplacian change in mean model
#' #produce samples
#' s=produce_samples(well_log, 100000, 1, 0.006)
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(well_log), s[[2]])
#' #draw the data and the credible regions
#' drawDataAndGreedyRegions(well_log, cr, length(s[[2]]), "Well-Log")
#'
#' ##produce samples from geometric change in success rate model and 1 changepoint
#' s=produceSamples(coal_mining_disasters, 100000, 3, 1)
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(coal_mining_disasters), s[[2]])
#' #draw the data and the credible regions
#' drawDataAndGreedyRegions(coal_mining_disasters, cr, length(s[[2]]), "Coal Mining Disasters")
#' @author Tobias Siems <tobias.siems@yahoo.com>
greedyHeuristic <-function(data_size, samples){
  return (greedy_heuristic(data_size, samples))
}


#' Produce Samples
#'
#' Given a dataset and a model, produce samples and their corresponding likelihoods
#'
#' @param data A dataset
#' @param sample_size The number of samples to be produced
#' @param model The model to use
#' @param d Success probability or number of changepoints respectively
#'
#' @details There are four different models available
#'
#' 0: Gaussian change in mean model with geometrically distributed sojourn times and success probability d
#'
#' 1: Laplacian in mean model with negative binomial distributed sojourn times where r=5 and success probability d
#'
#' 2: Gaussian change in variance model with d changepoints
#'
#' 3: Geometric change in success rate probability with d changepoints
#'
#' @return
#' Two lists that consists of the likelihood of a sample and the sample.
#' A sample is represented by a list of changepoint locations.
#'
#'
#' @examples
#' ##produce samples from gaussian change in mean model and d=3/550
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 3/550)
#'
#'
#' ##Produce samples for the Dow_Jones dataset with 5 changepoints
#' s=produce_samples(dow_jones, 100000, 2, 5)
#'
#'
#' ##Produce samples from Laplacian change in mean model and d=0.006 (This may take a while)
#' s=produceSamples(well_log, 100000, 1, 0.006)
#'
#'
#' ##produce samples from geometric change in success rate model and 1 changepoint
#' s=produceSamples(coal_mining_disasters, 100000, 3, 1)
#' @author Tobias Siems <tobias.siems@yahoo.com>
produceSamples <-function(data, sample_size, model, d){
  return (produce_samples(data, sample_size, model, d))
}

#' Joined highest density regions
#'
#' Compute joined highest density regions
#'
#' @param likelihood_and_samples Changepoint samples and their likelihoods
#' @param data_size Size of the dataset from which the sample where drawn
#' @param number_of_alphas The number of alphas the confidence intervals should be computed for
#' @examples
#'
#' ##Joined highest density regions for the gaussian change in mean example
#' #produce samples
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 3/550)
#' #get marginal changepoint probabilities and Bonferroni sets
#' cr=joinedHDR(s, length(gaussian_jumping_means), 29)
#' #draw the data and the joined highest density regions
#' drawDataAndCredibleRegions(gaussian_jumping_means, cr, "Gaussian change in mean")
#' @author Tobias Siems <tobias.siems@yahoo.com>
joinedHDR <-function(likelihood_and_samples, data_size, number_of_alphas){
  s=likelihood_and_samples[[2]][order(-likelihood_and_samples[[1]])]
  cr=list();
  counter=1;
  size=length(s)
  for(i in  1:number_of_alphas){
    alpha=.get_alpha(i, number_of_alphas)
    drop_size=ceiling(size*(1-alpha))
    cr[[counter]]=unique(unlist(s[1:drop_size]))
    counter=counter+1;
  }
  return (cr)
}
