#include"declarations.h"

#include<limits>


cdr eps=std::numeric_limits<double>::epsilon();


void get_vertical_coverage(csr sample_size, std::vector<index_unordered_set> &vertical_coverage, const std::vector<indexvec> &samples, csr data_size){
    if(sample_size>samples.size()){
        std::cout<<"To many samples!"<<std::endl;
        exit(0);
    }
    vertical_coverage=std::vector<index_unordered_set>(data_size);   //save at every index i in {1,...,n} a list of samples which hold a changepoint at i
    for(size_t i=0; i<sample_size; i++){
        for(auto it=samples[i].cbegin(); it!=samples[i].cend(); it++)
            vertical_coverage[*it]<<i;                                //save i at index (*it) if the sample i contains the time point (*it)
    }
}

std::ostream &operator<<(std::ostream &i, const triple &t){
    return i<<t.q<<", "<<t.m<<", "<<t.v<<"; ";
}






