#define __STDCPP_MATH_SPEC_FUNCS__
#include"declarations.h"
#include"random_stuff.h"
#include"my_time.h"

#include<random>
#include<iostream>
#include<set>

// [[Rcpp::depends(BH)]]
#include <Rcpp.h>

#include<boost/math/distributions/students_t.hpp>
#include<boost/math/distributions/negative_binomial.hpp>
#include<boost/random.hpp>

#include<cmath>

double sample_uniform(cdr a, cdr b){            //sample uniform
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(a, b);
    return dis(gen);
}
double phi(cdr x, cdr mean, cdr var){           //gauss pdf
    if(var<eps)
        return 0;
    static cdr denom=1/sqrt(2*M_PI);
    cdr d=(x-mean);
    return 1 / std::sqrt(var)*denom  * std::exp( -0.5 * d*d/var) ;
}
double student(cdr x, cdr free, cdr var){       //student-t pdf
    if(var<eps)
        return 1;
    return pow(free/(free+x*x/var), (1+free)/2)/(sqrt(free*var)*boost::math::beta(free/2, 0.5));
}
double student_abs(cdr x, cdr alpha, cdr beta){
    return alpha/(2*beta)*pow(beta/(std::abs(x)+beta), alpha+1);
}
double neg_binom_cdf(cir r, cdr q, cir k){
    boost::math::negative_binomial_distribution<double> nb(r,q);
    return boost::math::cdf(nb, k);
}
double neg_binom_inverse_cdf(cir r, cdr q, cir k){
    if(k<=0)
        return 1;
    boost::math::negative_binomial_distribution<double> nb(r,q);
    return boost::math::cdf(boost::math::complement(nb, k-1));
}
double neg_binom_pdf(cir r, cdr q, cir k){
    boost::math::negative_binomial_distribution<double> nb(r,q);
    return boost::math::pdf(nb, k);
}
double sample_gauss(cdr m, cdr s){
    typedef boost::normal_distribution<> dist;
    static boost::variate_generator<boost::mt19937, dist >
            generator(boost::mt19937(time(0)), dist());
    return std::sqrt(s)*generator()+m;
}

