//Author: Tobias Siems <tobias.siems@yahoo.com>
#ifndef GREEDY_H
#define GREEDY_H
#include"declarations.h"

class greedy{
public:
    greedy(csr data_size):data_size(data_size){}
    std::vector<std::pair<size_t, size_t>>  operator()(csr sample_size, const std::vector<indexvec> &samples);

private:
    csr data_size;

    void drop_samples(csr droped_timepoint, std::vector<index_unordered_set> &vertical_coverage, const std::vector<indexvec> &samples);
};

#endif // GREEDY_H
