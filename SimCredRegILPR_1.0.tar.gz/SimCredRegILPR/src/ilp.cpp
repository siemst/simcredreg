#include "ilp.h"
#include "my_time.h"
#include<Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
std::vector<indexlist> solve_ilp(csr data_size, csr sample_size, csr number_of_alphas, const std::vector<indexvec> &samples, bool show_cplex_output){
  return ilp(data_size, number_of_alphas)(sample_size, samples, show_cplex_output);
}

std::vector<indexlist> ilp::operator()(csr sample_size, const std::vector<indexvec> &samples, bool show){
  std::cout<<"CPLEX"<<std::endl;
  std::vector<index_unordered_set> vertical_coverage;   //save at every index i in {1,...,n} the list of samples which hold a changepoint at i
  get_vertical_coverage(sample_size, vertical_coverage, samples, data_size);   //fill vector "vertical_coverage"
  my_time time;                                                         //remember the starting time
  std::cout<<"building the ILP!"<<std::endl;

  std::vector<indexlist> cplex_solution;
  for(size_t i=0; i<number_of_alphas; i++){   //for every alpha in {1/30,2/30,...,29/30} compute a credible region
    csr drop_size=double(i+1)/(number_of_alphas+1)*sample_size; //maximal number of samples that can be droped
    std::cout<<"Computation step: "<<i+1<<" of "<<number_of_alphas<<std::endl;
    boolvec result_timepoints;    //save the result of the ILP
    cplex(sample_size, vertical_coverage, data_size, result_timepoints, drop_size, show);   //compute the credible region and save it to "result"
    indexlist l;    //save the credible region as an indexlist
    for(size_t i=0; i!=data_size; i++){
      if(result_timepoints[i]==1)
        l<<i;
    }
    cplex_solution<<l;
  }
  time.time_since_start();        //display the computation time
  std::cout<<"Done"<<std::endl;
  return cplex_solution;
}

void ilp::cplex(csr sample_size, const std::vector<index_unordered_set> &vertical_coverage
                  , csr data_size, boolvec &result_timepoints, csr dropsample_size, bool show_cplex_output){
  //calculate a credible region with the help of CPLEX and save it into result
  IloEnv env;
  IloRange drop_equation(env, 0, 0);
  IloBoolVarArray vars(env);
  for(size_t i=0; i<data_size+sample_size; i++)  //setting up the binary variables
    vars.add(IloBoolVar(env));
  for(size_t i=0; i<sample_size; i++)   //setting up the F_e variables
    drop_equation.setLinearCoef(vars[data_size+i], 1);
  //std::cout<<"F_e variables set!"<<std::endl;
  IloObjective obj = IloMaximize(env);
  IloRangeArray equations(env);
  try{
    for(size_t i=0; i<data_size; i++)  //setting up the U_x variables
      obj.setLinearCoef(vars[i], 1);
    //std::cout<<"U_x variables set!"<<std::endl;
    drop_equation.setBounds(0,dropsample_size);
    for(size_t i=0; i<data_size; i++){
      if(vertical_coverage[i].empty())
        continue;
      else if(vertical_coverage[i].size()>dropsample_size){
        equations.add(IloRange(env, -IloInfinity, 0));
        IloRange &eq=equations[equations.getSize()-1];
        eq.setLinearCoef(vars[i],1);
      } else {
        for(auto it=vertical_coverage[i].cbegin(); it!=vertical_coverage[i].cend(); it++){
          equations.add(IloRange(env, 0, IloInfinity));
          IloRange &eq=equations[equations.getSize()-1];
          eq.setLinearCoef(vars[data_size+(*it)], 1);
          eq.setLinearCoef(vars[i],-1);
        }
      }
    }
    IloModel model(env);
    model.add(obj);
    model.add(equations);
    model.add(drop_equation);
    IloCplex cplex(model);
    if(!show_cplex_output)
      cplex.setOut(env.getNullStream());  //suppress cplex output
    if (!cplex.solve() )
      env.error() << "Failed to optimize LP" << std::endl;

    IloNumArray vals(env);
    cplex.getValues(vals, vars);
    result_timepoints= boolvec(data_size);
    for(size_t i = 0; i < data_size; i++)
      result_timepoints[i]= !vals[i];
    equations.end();
    obj.end();
    env.end();
  } catch(const IloCplex::Exception &ex){
    std::cout<<"Exception caught: "<<ex.getMessage()<<std::endl;
    exit(0);
  }
  //std::cout<<"confidence_region_cplex ended!"<<std::endl;
}


