#ifndef INFERENCE_H
#define INFERENCE_H

#include"declarations.h"

#include<set>

class mglGraph;

//########################## Model inference ##################################
//Every model inherits from the class inference_t and from the inference_fixed_cp or inference_jump_prob.
//These base classes are abstract. Each class takes over its task as early as possible in the hierarchical order

class inference_t{
public:      
    inference_t():teta(1), delta(1){}
    inference_t(const probvec &data, cdr teta, cdr delta): data(data), teta(teta), delta(delta){}
    virtual void kalman()=0;
    virtual std::vector<std::pair<double, indexvec> > sample_and_likelihood(csr sample_size)=0;
    static inference_t *get_jump_inference(const probvec &data, model_type m_type, cdr jump_prob);
    static inference_t *get_fixed_cp_inference(const probvec &data, model_type m_type, csr changepoint_count);
    std::vector<std::pair<double, indexvec> > &get_samples();    

protected:    
    probvec data;
    const double teta;
    const double delta;    
    size_t data_size;
    size_t sample_weights_of_mixture(const std::vector<triple> &v);
    size_t sample_weights_of_mixture(const probvec &v);        
};
//##########################################################################################################################################################
class inference_fixed_cp: public virtual inference_t{
public:
    inference_fixed_cp(csr number_of_changepoints);
    virtual std::vector<std::pair<double, indexvec> > sample_and_likelihood(csr sample_size);
    virtual void kalman();
protected:
    virtual triple jump_posterior(cdr q, cdr y)=0;
    virtual triple kalman_posterior(const triple &old_t, cdr q, cdr y)=0;
    double jump_prior(csr changepoint, csr timepoint);
    const size_t number_of_changepoints;
    std::vector<std::vector<triplevec> > smoothy;
    std::vector<probvec> kth_jump_prob;
};
//##########################################################################################################################################################
class inference_jump_prob: public virtual inference_t{
public:
    inference_jump_prob(cdr jump_prob);
    virtual std::vector<std::pair<double, indexvec> > sample_and_likelihood(csr sample_size);
    virtual void kalman();
protected:
    const double jump_prob;
    std::vector<triplevec> smoothy;
    virtual triple jump_posterior(cdr q, cdr y)=0;
    virtual triple kalman_posterior(const triple &old_t, cdr y)=0;
};
//##########################################################################################################################################################
class inference_gauss_known_var_jump_prob: public inference_jump_prob{
public:
    inference_gauss_known_var_jump_prob(const probvec &data, cdr jump_prob, cdr teta, cdr delta);
protected:
    triple jump_posterior(cdr q, cdr y);
    triple kalman_posterior(const triple &old_t, cdr y);
};
//##########################################################################################################################################################
class inference_gauss_known_mean_fixed_cp: public inference_fixed_cp{
public:
    inference_gauss_known_mean_fixed_cp(const probvec &data, csr number_of_changepoints, cdr teta, cdr delta);
protected:
    triple jump_posterior(cdr q, cdr y);
    triple kalman_posterior(const triple &old_t, cdr q, cdr y);
};
//##########################################################################################################################################################
class inference_geometric_fixed_cp: public inference_fixed_cp{
public:
    inference_geometric_fixed_cp(const probvec &data, csr number_of_changepoints, cdr teta, cdr delta);
protected:
    triple jump_posterior(cdr q, cdr y);
    triple kalman_posterior(const triple &old_t, cdr q, cdr y);
};
//##########################################################################################################################################################
class inference_laplace_known_var_jump_prob: public inference_t{
public:
    inference_laplace_known_var_jump_prob(const probvec &data, cdr jump_prob, cdr teta, cdr delta);
    void viterbi();
    void kalman();    
    std::vector<std::pair<double, indexvec> > sample_and_likelihood(csr sample_size);
protected:
    const double jump_prob;
    std::vector<probvec> smoothy;
    double get_q(cdr sum_y, const probmultiset &l);
    double get_q_with_Z(cdr sum_y, const probmultiset &l, cdr Z);
};
//##########################################################################################################################################################
#endif // INFERENCE_H
