#include"greedy.h"
#include"my_time.h"

#include<algorithm>

#include<Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
std::vector<indexlist> greedy_heuristic(csr data_size, csr number_of_alphas, const std::vector<indexvec> &samples){
    return greedy(data_size, number_of_alphas)(samples.size(), samples);
}

std::vector<indexlist> greedy::operator()(csr sample_size, const std::vector<indexvec> &samples){
    std::cout<<"Computing credible regions according to the greedy heuristic!"<<std::endl;
    std::vector<std::pair<size_t, size_t>> droped_timepoints;
    my_time time;
    indexlist considered_timepoints;
    for(size_t i=0; i<data_size; i++)
        considered_timepoints<<i;
    std::vector<index_unordered_set> vertical_coverage;    
    //vertical coverage contains for every timepoint a list of samples with a changepoint at this timepoint
    get_vertical_coverage(sample_size, vertical_coverage, samples, data_size);
    while(true){
        auto timepoint_it=std::min_element(considered_timepoints.cbegin(), considered_timepoints.cend(),
                                           [&vertical_coverage](const auto &a, const auto &b){return vertical_coverage[a].size()<vertical_coverage[b].size();});
        if(timepoint_it==considered_timepoints.cend())
            break;
        csr timepoint=(*timepoint_it);
        const index_unordered_set &l=vertical_coverage[timepoint];
        droped_timepoints<<std::pair<size_t, size_t>(timepoint, l.size());          //save the timepoint together with the number of samples droped
        drop_samples(timepoint, vertical_coverage, samples);
        considered_timepoints.erase(timepoint_it);
    }
    //for each alpha compute regions from droped_timepoints
    std::vector<indexlist> credible_regions;
    for(size_t i=0; i<number_of_alphas; i++){
        cdr alpha=double(i+1)/(number_of_alphas+1);
        indexlist region;
        get_greedy_region(alpha, sample_size, region, droped_timepoints);
        credible_regions<<region;
    }
    time.time_since_start();
    std::cout<<"Done"<<std::endl;
    return credible_regions;
}

void greedy::drop_samples(csr droped_timepoint, std::vector<index_unordered_set> &vertical_coverage, const std::vector<indexvec> &samples){
    const index_unordered_set l=vertical_coverage[droped_timepoint];
    for(auto it=l.cbegin(); it!=l.cend(); it++){
        for(auto it2=samples[*it].cbegin(); it2!=samples[*it].cend(); it2++)
            vertical_coverage[*it2].erase(*it);
    }
}

void greedy::get_greedy_region(cdr alpha, csr sample_size, indexlist &region, const std::vector<std::pair<size_t, size_t> > &heuristic_solution){
    //    std::cout<<"greedy region"<<std::endl;
    if(heuristic_solution.empty())
        return;
    size_t droped_samples=0;
    auto it=heuristic_solution.cbegin();
    region.clear();
    for(size_t i=0; i<data_size; i++)
        region<<i;
    while(true){
        if(droped_samples+it->second>alpha*sample_size)
            break;
        region.remove(it->first);
        droped_samples+=it->second;
        it++;
    }
    //    std::cout<<"Done"<<std::endl;
}
