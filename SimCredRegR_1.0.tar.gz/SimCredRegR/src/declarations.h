#ifndef DECLARATIONS_H
#define DECLARATIONS_H

//########################## typedefs and operator overloadings in order to produce beautiful source code :) ##################################
#include<stddef.h>
#include<vector>
#include<unordered_set>
#include<set>
#include<list>
#include<iostream>



typedef const double & cdr;
typedef const size_t & csr;
typedef const int & cir;
typedef const bool & cbr;
typedef std::list<size_t> indexlist;
typedef std::vector<size_t> indexvec;
typedef std::vector<bool> boolvec;
typedef std::vector<double> probvec;
typedef std::list<double> problist;
typedef std::set<double> probset;
typedef std::multiset<double> probmultiset;
typedef std::unordered_multiset<size_t> index_unordered_set;
typedef std::set<size_t> indexset;
typedef std::list<size_t>::const_iterator cli;

extern cdr eps;
enum model_type {gauss_known_var_jump_prob, laplace_known_var_jump_prob, gauss_known_mean_fixed_cp, geometric_fixed_cp};


struct triple{  //represents a component (normal distribution) and a weight in a mixture distribution
    //it consists of a double valued weight, mean and variance of a normal distribution
    triple(){}
    triple(cdr arg_q, cdr arg_m, cdr arg_v):q(arg_q),m(arg_m),v(arg_v){}

    double q;   //weight
    double m;   //mean
    double v;   //variance
};
typedef std::vector<triple> triplevec;

void get_vertical_coverage(csr sample_size, std::vector<index_unordered_set> &vertical_coverage, const std::vector<indexvec> &samples, csr data_size);

//##########################################################################################################################################################
//##########################################################################################################################################################
//###############################################################                       ####################################################################
//############################################################### operator overloadings ####################################################################
//###############################################################                       ####################################################################
//##########################################################################################################################################################
//##########################################################################################################################################################
template<typename T>
std::vector<T> &operator<<(std::vector<T> &v, const T &d){
    v.push_back(d);
    return v;
}
template<typename T>
std::vector<T> &operator<<(std::vector<T> &v, const std::vector<T> &d){
    for(auto it=d.cbegin(); it!=d.cend(); it++)
        v.push_back(*it);
    return v;
}
template<typename T>
std::vector<T> &operator<<(std::vector<T> &&v, const T &d){
    v.push_back(d);
    return v;
}
template<typename T>
std::multiset<T> &operator<<(std::multiset<T> &&v, const T &d){
    v.insert(d);
    return v;
}
template<typename T>
std::set<T> &operator<<(std::set<T> &&v, const T &d){
    v.insert(d);
    return v;
}
template<typename T>
std::set<T> &operator<<(std::set<T> &v, const T &d){
    v.insert(d);
    return v;
}
template<typename T>
std::set<T> &operator<<(std::set<T> &v, const std::vector<T> &v2){
    for(auto it=v2.cbegin(); it!=v2.cend(); it++)
        v.insert(*it);
    return v;
}
template<typename T>
std::multiset<T> &operator<<(std::multiset<T> &v, const T &d){
    v.insert(d);
    return v;
}
template<typename T>
std::unordered_set<T> &operator<<(std::unordered_set<T> &v, const T &d){
    v.insert(d);
    return v;
}
template<typename T>
std::unordered_multiset<T> &operator<<(std::unordered_multiset<T> &v, const T &d){
    v.insert(d);
    return v;
}
template<typename T>
T operator+=(T &d, const std::vector<T> &v){
    for(auto it=v.cbegin(); it!= v.cend(); it++)
        d+=(*it);
    return d;
}
template<typename T>
std::vector<T> &operator/=(std::vector<T> &v, T &d){
    for(auto it=v.begin(); it!=v.end(); it++)
        (*it)/=d;
    return v;
}
template<typename T>
T operator+(const T &a, const std::vector<T> &v){
    T d=0;
    for(auto it=v.cbegin(); it!= v.cend(); it++)
        d+=(*it);
    return d+a;
}
template<typename T>
T operator+(const std::vector<T> &v, const T &a){
    T d=0;
    for(auto it=v.cbegin(); it!= v.cend(); it++)
        d+=(*it);
    return d+a;
}
template<typename T>
std::list<T> &operator<<(std::list<T> &v, const T &d){
    v.push_back(d);
    return v;
}
template<typename T>
std::list<T> &operator<<(std::list<T> &v, const std::list<T> &d){
    for(auto it=d.cbegin(); it!=d.cend(); it++)
        v.push_back(*it);
    return v;
}
template<typename T>
std::list<T> &operator<<(std::list<T> &v, const std::vector<T> &d){
    for(auto it=d.cbegin(); it!=d.cend(); it++)
        v.push_back(*it);
    return v;
}
template<typename T>
std::list<T> &operator<<(std::list<T> &&v, const T &d){
    v.push_back(d);
    return v;
}

std::ostream &operator<<(std::ostream &i, const triple &t);
template<typename T>
std::ostream &operator<<(std::ostream &i, const std::vector<T> v){
    for(auto it=v.cbegin(); it!=v.cend(); it++)
        i<<(*it)<<", ";
    return i;
}
template<typename T, typename L>
std::ostream &operator<<(std::ostream &i, const std::pair<T, L> p){
//    i<<p.first<<" <=> "<<p.second;
    i<<p.first<<": "<<p.second<<std::endl;

    return i;
}
template<typename T>
std::ostream &operator<<(std::ostream &i, const std::list<T> v){
    for(auto it=v.cbegin(); it!=v.cend(); it++)
        i<<(*it)<<", ";
    return i;
}
template<typename T>
std::ostream &operator<<(std::ostream &i, const std::set<T> v){
    for(auto it=v.cbegin(); it!=v.cend(); it++)
        i<<(*it)<<", ";
    return i;
}
template<typename T>
std::ostream &operator<<(std::ostream &i, const std::multiset<T> v){
    for(auto it=v.cbegin(); it!=v.cend(); it++)
        i<<(*it)<<", ";
    return i;
}
template<typename T>
size_t index_of_reverse_iterator(const T &t, typename T::const_reverse_iterator it){    //return the index of an reverse iterator
    return std::distance(t.begin(),it.base())-1;
}


#endif // DECLARATIONS_H

