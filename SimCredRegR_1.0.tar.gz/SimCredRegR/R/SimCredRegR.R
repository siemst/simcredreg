#' SimCredRegR
#'
#' This package is part of the supplementary material of the paper "Simultaneous Credible Regions for Multiple Changepoint Locations".
#'
#' Primarily, we provide a fast implementation of the greedy heuristic as introduced in the paper.
#' However, you can find the datasets that where used throughout the paper, it provides drawing
#' and some sampling routines.
#'
#'
#'
#' You can find the following functions:
#'
#' \itemize{
#'
#' \item greedyHeuristic(...)  Fast implemmentation of the greedy heuristic
#'
#' \item extractCredibleRegionFromGreedyOutput(...) Extract a credible region from a greedy output
#'
#'
#' \item drawDataAndGreedyRegions(...) Draw data and greedy regions
#'
#' \itemize{
#'
#' \item drawData(...)
#'
#' \item drawGreedyRegions(...)
#'
#' \item addGreedyRegions(...)
#'
#' }
#'
#' \item produceSamples(...)     Compute samples according to a given dataset and model
#'
#' \item jCFSmuce(...) Compute stepR's joined confidence intervals
#'
#' \item marginals(...) Compute marginal changepoint probabilities and Bonferroni sets
#'
#' \item joinedHDR(...) Compute joined highest density regions
#'
#' \item drawDataAndCredibleRegions(...) Draw data and credible regions
#'
#' \itemize{
#'
#' \item drawCredibleRegions(...)
#'
#' \item addCredibleRegions(...)
#'
#' }
#'
#'
#' }
#'
#' And the following datasets
#' \itemize{
#' \item gaussian_jumping_means
#' \item dow_jones
#' \item well_log
#' \item coal_mining_disasters
#' }
#'
#' Documentations of this functions and datasets are provided, e.g. type '?greedyHeuristic'.
#' @author Tobias Siems <tobias.siems@yahoo.com>
#' @name SimCredRegR
NULL

#' gaussian_jumping_means Dataset
#'
#' An artificial dataset consisting of Gaussian observations with a constant variance of 1 and mean values that are subject to successive jumps.
#'
#' It was produced as follows:
#' @source
#' y=c(rnorm(100,mean=0,sd=1),rnorm(100,mean=0.5,sd=1),rnorm(50,mean=-1.5,sd=1),rnorm(30,mean=1.5,sd=1), rnorm(20,mean=2.5,sd=1),rnorm(20,mean=-3.5,sd=1),rnorm(15,mean=3,sd=1), rnorm(15,mean=-4,sd=1),rnorm(100,mean=1,sd=1),rnorm(100,mean=0,sd=1))
#' @author Tobias Siems <tobias.siems@yahoo.com>
#' @name gaussian_jumping_means
NULL



#' dow_jones Dataset
#'
#' Dow Jones returns observed between 1972 and 1975 (Adams and McKay 2007: Bayesian online changepoint detection).
#' @name dow_jones
NULL



#' well_log Dataset
#'
#' Well-log dataset that stems from nuclear-magnetic response of underground rocks (Fearnhead 2006:  Exact and efficient Bayesian inference for multiple changepoint problems).
#' @name well_log
NULL



#' coal_mining_disasters
#'
#' 191 successive timepoints of coal mine explosions, that killed ten or more men between March 15, 1851 and March 22, 1962 (Trenkler 1995:  A handbook of small data sets ).
#' @name coal_mining_disasters
NULL
