#' Draw a given dataset and credible regions among each other.
#'
#' @param data A dataset
#' @param credible_regions Credible regions
#' @param title The title printed above the dataset
#' @examples
#'
#' #produce samples
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 0.0005)
#'
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(gaussian_jumping_means), 20, s[[2]])
#'
#' #draw the data and the credible regions
#' drawCredibleRegions(gaussian_jumping_means, cr, "Gaussian change in mean")
drawDataAndCredibleRegions <- function(data, credible_regions, title=""){
  require(latex2exp)
  par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
  drawData(data, title)
  drawCredibleRegions(credible_regions, length(data), "black")
}





#' Compute joined confidence sets using stepR. Will only work for a Gaussian change in mean dataset.
#'
#' @param data A dataset
#' @param number_of_alphas The number of alphas the confidence intervalls should be computed for
#' @examples
#'
#' #compute joined confidence sets with stepR
#' cf=jCFSmuce(gaussian_jumping_means, 29)
#'
#' #draw the data and the joined confidence sets
#' drawDataAndCredibleRegions(gaussian_jumping_means, cf, "Gaussian change in mean")
jCFSmuce <- function(data, number_of_alphas){  #n is the number of confidence sets
  require(stepR)
  k=list()
  for(i in 1:(number_of_alphas)){
    a=.get_alpha(i, number_of_alphas)
    b <- bounds(data, family="gauss", alpha=a, param=1)
    # fit step function
    sb <- stepbound(data, b, family="gauss", jumpint = TRUE)
    j=jumpint(sb)
    k=append(k,list(cbind(j[,3],j[,4])))
  }
  confidence_regions=list()
  for(i in 1:length(k)){
    region=c();
    for(j in 1:length(k[[i]][,1])){
      region=c(region,k[[i]][j,1]:k[[i]][j,2])
    }
    confidence_regions=append(confidence_regions, list(region[1:(length(region)-1)]))
  }
  d=k
  reg=list()
  for(i in 1:length(d)){
    myreg=c();
    for(j in 1:length(d[[i]][,1])){
      myreg=c(myreg,d[[i]][j,1]:d[[i]][j,2])
    }
    reg=append(reg, list(myreg))
  }
  return(reg)
}






#' Compute marginal changepoint probabilities and Bonferroni sets
#'
#' @param samples Changepoint samples
#' @param data_size Size of the dataset from which the sample where drawn
#' @param number_of_alphas The number of alphas the confidence intervalls should be computed for
#' @return Two lists, first the regions derived by marginal changepoint probabilities and second the Bonferroni sets
#' @examples
#'
#' #produce samples
#' s=produceSamples(dow_jones, 100000, 2, 5)
#'
#' #get marginal changepoint probabilities and Bonferroni sets
#' m=marginals(s[[2]], length(dow_jones), 29)
#'
#' #produce plot
#' par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
#' drawData(dow_jones, "Dow Jones")
#' drawCredibleRegions(m[[2]], length(dow_jones), "gray")
#' addCredibleRegions(m[[1]], length(dow_jones), color="black")
marginals <- function(samples, data_size, number_of_alphas){
  marginals=rep(0, data_size)
  sample_size=length(samples)
  for(i in 1:sample_size){
    for(j in 1:length(samples[[i]]))
      marginals[samples[[i]][j]]=marginals[samples[[i]][j]]+1;
  }
  for(i in 1:data_size)
    marginals[i]=marginals[i]/sample_size
  marginal_regions=c()
  bonferroni_regions=c()
  for(i in  1:number_of_alphas){
    marginal_region=c()
    bonferroni_region=c()
    alpha=.get_alpha(i ,number_of_alphas)
    for(j in 1:data_size){
      if(marginals[j]>alpha/data_size)
        bonferroni_region=c(bonferroni_region, j)
      if(marginals[j]>alpha)
        marginal_region=c(marginal_region, j)
    }
    marginal_regions=c(marginal_regions, list(marginal_region))
    bonferroni_regions=c(bonferroni_regions, list(bonferroni_region))
  }
  return (list(marginal_regions, bonferroni_regions))
}

#' Compute credible regions according to greedy
#'
#' @param data_size Size of the dataset from which the sample where drawn
#' @param number_of_alphas The number of alphas the confidence intervalls should be computed for
#' @param samples Changepoint samples
#' @examples
#'
#' #produce samples
#' s=produce_samples(dow_jones, 100000, 2, 5)
#'
#' #computecredible regions
#' cr=greedyHeuristic(length(dow_jones), 29, s[[2]])
#'
#' #Draw
#' drawDataAndCredibleRegions(dow_jones, cr, "Dow Jones")
greedyHeuristic <-function(data_size, number_of_alphas, samples){
  return (greedy_heuristic(data_size, number_of_alphas, samples))
}


#' Given a dataset and a model, produce samples and their corresponding likelihoods
#'
#' @param data A dataset
#' @param sample_size The number of samples to be produced
#' @param model The model to use
#' @param d Success probability or number of changepoints respectively
#'
#' @details There are for different models availabale
#'
#' 0: Gaussian change in mean model with geometric distributed sjourn times and success probability d
#'
#' 1: Laplacian in mean model with negative binomial distributed sojourn times where r=5 and success probability d
#'
#' 2: Gaussian change in variance model with d changepoints
#'
#' 3: Geomtric change in success rate probability with d changepoints
#'
#' @return
#'
#'
#' @examples
#' ##produce samples from gaussian change in mean model and d=0.0005
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 0.0005)
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(gaussian_jumping_means), 29, s[[2]])
#' #draw the data and the credible regions
#' drawDataAndCredibleRegions(gaussian_jumping_means, cr, "Gaussian change in mean")
#'
#'
#' ##produce samples from the Gaussian change in variance model with 5 changepoints
#' s=produce_samples(dow_jones, 100000, 2, 5)
#' #computecredible regions
#' cr=greedyHeuristic(length(dow_jones), 29, s[[2]])
#' #Draw
#' drawDataAndCredibleRegions(dow_jones, cr, "Dow Jones")
#'
#'
#' ##produce samples from Laplacian change in mean model and d=0.006 (This may take a while)
#' s=produceSamples(well_log, 100000, 1, 0.006)
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(well_log), 29, s[[2]])
#' #draw the data and the credible regions
#' drawDataAndCredibleRegions(well_log, cr, "Well-Log")
#'
#'
#' ##produce samples from geometric change in success rate model and 1 changepoint
#' s=produceSamples(coal_mining_disasters, 100000, 3, 1)
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(coal_mining_disasters), 29, s[[2]])
#' #draw the data and the credible regions
#' drawDataAndCredibleRegions(coal_mining_disasters, cr, "Coal Mining Disasters")
produceSamples <-function(data, sample_size, model, d){
  return (produce_samples(data, sample_size, model, d))
}



#' Compute joined highest density regions
#'
#' @param likelihood_and_samples Changepoint samples and their likelihoods
#' @param data_size Size of the dataset from which the sample where drawn
#' @param number_of_alphas The number of alphas the confidence intervalls should be computed for
#' @examples
#'
#' #produce samples
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 0.0005)
#'
#' #get marginal changepoint probabilities and Bonferroni sets
#' cr=joinedHDR(s, length(gaussian_jumping_means), 29)
#'
#' #draw the data and the joined highest density regions
#' drawDataAndCredibleRegions(gaussian_jumping_means, cr, "Gaussian change in mean")
joinedHDR <-function(likelihood_and_samples, data_size, number_of_alphas){
  s=likelihood_and_samples[[2]][order(-likelihood_and_samples[[1]])]
  cr=list();
  counter=1;
  size=length(s)
  for(i in  1:number_of_alphas){
    alpha=.get_alpha(i, number_of_alphas)
    drop_size=ceiling(size*(1-alpha))
    cr[[counter]]=unique(unlist(s[1:drop_size]))
    counter=counter+1;
  }
  return (cr)
}
