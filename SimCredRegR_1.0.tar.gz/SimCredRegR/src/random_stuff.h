#ifndef RANDOM_STUFF_H
#define RANDOM_STUFF_H

#include"declarations.h"

//########################## some densities and sampling algorithms ##################################


class mglGraph;

double sample_uniform(cdr a=0, cdr b=1);    //sample uniform
double sample_gauss(cdr m, cdr s);
double phi(cdr x, cdr mean, cdr var);       //gauss pdf
double student(cdr x, cdr free, cdr var);   //students-t pdf
double student_abs(cdr x, cdr alpha, cdr beta);
double neg_binom_cdf(cir r, cdr q, cir k);
double neg_binom_inverse_cdf(cir r, cdr q, cir k);
double neg_binom_pdf(cir r, cdr q, cir k);




#endif // RANDOM_STUFF_H

