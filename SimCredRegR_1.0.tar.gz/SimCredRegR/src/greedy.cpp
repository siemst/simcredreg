//Author: Tobias Siems <tobias.siems@yahoo.com>
#include"greedy.h"
#include"my_time.h"

#include<algorithm>

#include<Rcpp.h>
using namespace Rcpp;

void get_greedy_region(cdr alpha, csr sample_size, indexlist &region, const std::vector<std::pair<size_t, size_t>> &heuristic_solution, csr data_size);

// [[Rcpp::export]]
List greedy_heuristic(csr data_size, const std::vector<indexvec> &samples){
  std::vector<std::pair<size_t, size_t>> droped_timepoints=greedy(data_size)(samples.size(), samples);
  indexlist sizes;
  indexlist timepoints;
  for(auto it=droped_timepoints.cbegin(); it!= droped_timepoints.cend(); it++){
    timepoints<<it->first+1;
    sizes<<it->second;
  }
  return List::create(timepoints, sizes);
}

std::vector<std::pair<size_t, size_t>> greedy::operator()(csr sample_size, const std::vector<indexvec> &samples){
  std::cout<<"Computing credible regions according to the greedy heuristic!"<<std::endl;
  std::vector<std::pair<size_t, size_t>> droped_timepoints;
  my_time time;
  indexlist considered_timepoints;
  for(size_t i=0; i<data_size; i++)
    considered_timepoints<<i;
  std::vector<index_unordered_set> vertical_coverage;
  //vertical coverage contains for every timepoint a list of samples with a changepoint at this timepoint
  get_vertical_coverage(sample_size, vertical_coverage, samples, data_size);
  while(true){
    auto timepoint_it=std::min_element(considered_timepoints.cbegin(), considered_timepoints.cend(),
                                       [&vertical_coverage](const auto &a, const auto &b){return vertical_coverage[a].size()<vertical_coverage[b].size();});
    if(timepoint_it==considered_timepoints.cend())
      break;
    csr timepoint=(*timepoint_it);
    const index_unordered_set &l=vertical_coverage[timepoint];
    droped_timepoints<<std::pair<size_t, size_t>(timepoint, l.size());          //save the timepoint together with the number of samples droped
    drop_samples(timepoint, vertical_coverage, samples);
    considered_timepoints.erase(timepoint_it);
  }
  time.time_since_start();
  return droped_timepoints;
}


void greedy::drop_samples(csr droped_timepoint, std::vector<index_unordered_set> &vertical_coverage, const std::vector<indexvec> &samples){
    const index_unordered_set l=vertical_coverage[droped_timepoint];
    for(auto it=l.cbegin(); it!=l.cend(); it++){
        for(auto it2=samples[*it].cbegin(); it2!=samples[*it].cend(); it2++)
            vertical_coverage[*it2].erase(*it);
    }
}

void get_greedy_region(cdr alpha, csr sample_size, indexlist &region, const std::vector<std::pair<size_t, size_t> > &heuristic_solution, csr data_size){
    //    std::cout<<"greedy region"<<std::endl;
    if(heuristic_solution.empty())
        return;
    size_t droped_samples=0;
    auto it=heuristic_solution.cbegin();
    region.clear();
    for(size_t i=0; i<data_size; i++)
        region<<i;
    while(true){
        if(droped_samples+it->second>alpha*sample_size)
            break;
        region.remove(it->first);
        droped_samples+=it->second;
        it++;
    }
    //    std::cout<<"Done"<<std::endl;
}
