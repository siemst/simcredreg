#' Draw data and credible regions
#'
#' Draw a given dataset and credible regions among each other.
#'
#' @param data A dataset
#' @param credible_regions Credible regions
#' @param title The title printed above the dataset
#' @examples
#'
#' ##Joined highest density regions for the gaussian change in mean example
#' #produce samples
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 3/550)
#' #get marginal changepoint probabilities and Bonferroni sets
#' cr=joinedHDR(s, length(gaussian_jumping_means), 29)
#' #draw the data and the joined highest density regions
#' drawDataAndCredibleRegions(gaussian_jumping_means, cr, "Gaussian change in mean")
#' @author Tobias Siems <tobias.siems@yahoo.com>
drawDataAndCredibleRegions <- function(data, credible_regions, title=""){
  require(latex2exp)
  par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
  drawData(data, title)
  drawCredibleRegions(credible_regions, length(data), "black")
}

#' Draw data and greedy output
#'
#' Draw a given dataset and greedy regions among each other.
#'
#' Draws bars for each time point.
#' The height of the bar is the relative number of samples that where droped till the point was removed.
#'
#'
#' @param data A dataset
#' @param greedy_regions Greedy regions
#' @param sample_size The number of samples
#' @param title The title printed above the dataset
#' @examples
#'
#' #produce samples
#' s=produceSamples(gaussian_jumping_means, 100000, 0, 3/550)
#'
#' #compute credible regions accoring to greedy
#' cr=greedyHeuristic(length(gaussian_jumping_means), s[[2]])
#'
#' #draw the data and the credible regions
#' drawDataAndGreedyRegions(gaussian_jumping_means, cr, length(s[[2]]), "Gaussian change in mean")
#' @author Tobias Siems <tobias.siems@yahoo.com>
drawDataAndGreedyRegions <- function(data, greedy_regions, sample_size, title=""){
  require(latex2exp)
  par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
  drawData(data, title)
  drawGreedyRegions(greedy_regions, length(data), sample_size, "black")
}


#' Add credible regions to an existing plot
addCredibleRegions <-function(credible_regions, data_size, color){
  delta=0.009;
  for(i in 1:length(credible_regions)){
    region=sort(credible_regions[[i]], decreasing = TRUE)
    b=region[1]
    alpha=.get_alpha(i, length(credible_regions))
    if(length(region)==0)
      next
    if(length(region)==1){
      rect(b-60*delta, alpha-1*delta, b+60*delta, alpha+1*delta, col = color, border = color, lwd=0)
      next
    }
    old=b
    for(j in 2:length(region)){
      if(region[j]==old+1)
        old=old+1
      else{
        rect(b-60*delta, alpha-1*delta, old+60*delta, alpha+1*delta, col = color, border = color, lwd=0)
        b=region[j]
        old=b
      }
    }
    rect(b-60*delta, alpha-1*delta, b+60*delta, alpha+1*delta, col = color, border = color, lwd=0)
  }
}
#' Add greedy regions to an existing plot
addGreedyRegions <-function(cr, data_size, sample_size, color){
  counter=0
  delta=1/2
  #lines(x = cr[[1]][order(cr[[1]])], y = cumsum(cr[[2]])[order(cr[[1]])]/sample_size, lwd=1)
  for(i in 1:length(cr[[1]])){
    counter=counter+cr[[2]][i]
    x=cr[[1]][i];
    y=counter/sample_size
    rect(x-delta, 0, x+delta, y, col = color, border = color, lwd=0)
  }
}
#' Draw greedy regions
drawGreedyRegions <- function(greedy_regions, data_size, sample_size, color="black"){
  require(latex2exp)
  plot(1, type="n", xlab="", ylab="", xlim=c(1, data_size), ylim=c(0, 1), las=1, xaxt='n', yaxt='n')
  mtext("Simultaneous credible regions", side=3, line=0.5)
  axis(2, at = c(0, 0.3, 0.6, 0.9), las=2)
  title(ylab=TeX("$\\alpha$"), line=2.3, cex.lab=1.5, adj=0.9)
  addGreedyRegions(greedy_regions, data_size, sample_size, color)
  old=0
}
#' Draw credible regions
drawCredibleRegions <- function(credible_regions, data_size, color="black"){
  require(latex2exp)
  plot(1, type="n", xlab="", ylab="", xlim=c(1, data_size), ylim=c(0, 1), las=1, xaxt='n', yaxt='n')
  mtext("Simultaneous credible regions", side=3, line=0.5)
  axis(2, at = c(0, 0.3, 0.6, 0.9), las=2)
  title(ylab=TeX("$\\alpha$"), line=2.3, cex.lab=1.5, adj=0.9)
  addCredibleRegions(credible_regions, data_size, color)
  old=0
}
#' Draw data
drawData <- function(data, title=""){
  require(latex2exp)
  par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
  plot(data, cex=0.2, xlab="", bg = "black", las=1, ylab="", ylim = c(min(data), max(data)));
  #axis(2, at = c(round(min(data)), 0, round(max(data))), las=2)
  mtext(title, side=3, line=0.5)
  title(ylab=TeX("$y_i$"), line=3, cex.lab=1.5, adj=0.9)
  title(xlab=TeX("$i$"), line=1, cex.lab=1.5, adj=0.95)
  min=par("usr")[3]
  max=par("usr")[4]
  delta=(max-min)/50
  old=0;
}
