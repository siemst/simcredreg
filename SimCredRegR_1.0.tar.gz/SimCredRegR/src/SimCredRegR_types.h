#ifndef DECLARATIONS_H
#define DECLARATIONS_H

//########################## typedefs and operator overloadings in order to produce beautiful source code :) ##################################
#include<stddef.h>
#include<vector>
#include<unordered_set>
#include<set>
#include<list>



typedef const double & cdr;
typedef const size_t & csr;
typedef const int & cir;
typedef const bool & cbr;
typedef std::list<size_t> indexlist;
typedef std::vector<size_t> indexvec;
typedef std::vector<bool> boolvec;
typedef std::vector<double> probvec;
typedef std::list<double> problist;
typedef std::set<double> probset;
typedef std::multiset<double> probmultiset;
typedef std::unordered_multiset<size_t> index_unordered_set;
typedef std::set<size_t> indexset;
typedef std::list<size_t>::const_iterator cli;

enum model_type {gauss_known_var_jump_prob, laplace_known_var_jump_prob, gauss_known_mean_fixed_cp, geometric_fixed_cp};



#endif // DECLARATIONS_H

