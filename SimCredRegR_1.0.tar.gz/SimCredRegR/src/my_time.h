#ifndef MY_TIME_H
#define MY_TIME_H

#include<ctime>

class my_time   //handle the time a process takes
{
public:
    my_time();
    size_t time_since_start(bool give_time=true);    
private:
    std::time_t start;
};

#endif // MY_TIME_H
