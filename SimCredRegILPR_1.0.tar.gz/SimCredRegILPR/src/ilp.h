#ifndef ILP_H
#define ILP_H

#include<ilcplex/ilocplex.h>

#include"declarations.h"

class ilp{
public:
    ilp(csr data_size, csr number_of_alphas):data_size(data_size), number_of_alphas(number_of_alphas){}
    std::vector<indexlist> operator()(csr sample_size, const std::vector<indexvec> &samples, bool show);
private:
    void cplex(csr sample_size, const std::vector<index_unordered_set> &vertical_coverage, csr data_size, boolvec &result_timepoints
               , csr dropsample_size, bool show_cplex_output=true);

    csr data_size;
    csr number_of_alphas;
};

#endif // ILP_H
