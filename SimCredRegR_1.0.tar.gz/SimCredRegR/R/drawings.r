.get_alpha<- function(i, number_of_alphas){
  return (i/(number_of_alphas+1))
}
#' Add credible regions to an existing plot
addCredibleRegions <-function(credible_regions, data_size, color){
  delta=0.009;
  for(i in 1:length(credible_regions)){
    region=credible_regions[[i]]
    b=region[1]
    alpha=.get_alpha(i, length(credible_regions))
    if(length(region)<2){
      rect(b-60*delta, alpha-1*delta, b+60*delta, alpha+1*delta, col = color, border = color, lwd=0)
      next
    }
    old=b
    for(j in 2:length(region)){
      if(region[j]==old+1)
        old=old+1
      else{
        rect(b-60*delta, alpha-1*delta, old+60*delta, alpha+1*delta, col = color, border = color, lwd=0)
        b=region[j]
        old=b
      }
    }
    rect(b-60*delta, alpha-1*delta, old+60*delta, alpha+1*delta, col = color, border = color, lwd=0)
  }
}
#' Draw credible regions
drawCredibleRegions <- function(credible_regions, data_size, color="black"){
  require(latex2exp)
  plot(1, type="n", xlab="", ylab="", xlim=c(1, data_size), ylim=c(0, 1), las=1, xaxt='n', yaxt='n')
  axis(2, at = c(0, 0.3, 0.6, 0.9), las=2)
  title(ylab=TeX("$\\alpha$"), line=2.3, cex.lab=1.5, adj=0.9)
  addCredibleRegions(credible_regions, data_size, color)
  old=0
}
#' Draw data
drawData <- function(data, title=""){
  require(latex2exp)
  par(mfrow=c(2,1), mar=c(1, 5, 1, 1) + 1)
  plot(data, cex=0.2, xlab="", bg = "black", las=1, ylab="", ylim = c(min(data), max(data)));
  #axis(2, at = c(round(min(data)), 0, round(max(data))), las=2)
  mtext(title, side=3, line=0.5)
  title(ylab=TeX("$y_i$"), line=3, cex.lab=1.5, adj=0.9)
  title(xlab=TeX("$i$"), line=1, cex.lab=1.5, adj=0.95)
  min=par("usr")[3]
  max=par("usr")[4]
  delta=(max-min)/50
  old=0;
}
