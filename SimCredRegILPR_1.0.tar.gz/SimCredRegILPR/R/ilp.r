#' Greedy Heuristic
#'
#' Implemmentation of the ILP.
#' Can be used in combination with the R package SimCredRegR.
#'
#' @param samples Changepoint samples
#' @param number_of_alphas The number of alphas
#' @param data_size The size of the dataset
#' @param show_output If TRUE you will see the output of CPLEX
#'
#' @examples
#' ##ILP for the Gaussian change in mean dataset
#' require(SimCredRegR)
#' #produce samples
#' s=produce_samples(gaussian_jumping_means, 10000, 0, 0.0005)
#' #compute credible regions
#' cr=ilpCR(s[[2]], 29, length(gaussian_jumping_means), FALSE)
#' #Draw
#' drawDataAndCredibleRegions(gaussian_jumping_means, cr, "Gaussian change in mean")
#' @author Tobias Siems <tobias.siems@yahoo.com>
ilpCR <- function(samples, number_of_alphas, data_size, show_output=FALSE){
  return (solve_ilp(data_size, length(samples), number_of_alphas, samples, show_output))
}
#' SimCredRegILPR
#'
#'
#' This package is part of the supplementary material of the paper "Simultaneous Credible Regions for Multiple Changepoint Locations".
#'
#' An implementation of the ILP is provided.
#'
#' \itemize{
#'
#' \item ilpCR(...)
#'
#' }
#'
#' You can find an explanation by typing ?ilpCR.
#' @name SimCredRegILPR

NULL

addFLAGS <- function(s,a){
  arg=list(paste(Sys.getenv(s), a));
  names(arg)=s;
  do.call(Sys.setenv, arg)
}
setEnvironment <- function(){
  cplex_path=""
  addFLAGS("PKG_CXXFLAGS", "-std=c++17");

  if(cplex_path=="")
    cat("\n
        ##################################################################################################################################\n
         There is no cplex path given in ilp.r. Solving ILP's is not available unless you set a proper path to cplex_path in stuff.r\n
         For example: \"/home/user/cplex\"\n
        ##################################################################################################################################")
  else{
    addFLAGS("PKG_CXXFLAGS", paste("-I ", cplex_path, "/cplex/include", " -I ", cplex_path, "/concert/include", sep=""))
    addFLAGS("PKG_LIBS", paste(" -L ", cplex_path, "/cplex/lib/x86-64_linux/static_pic"
                               , " -L ", cplex_path, "/concert/lib/x86-64_linux/static_pic -lconcert -lilocplex -lcplex", sep=""))
    addFLAGS("PKG_CXXFLAGS", "-DIL_STD");
  }
}
clearEnvironment <- function(){
  Sys.setenv("PKG_CXXFLAGS"="")
  Sys.setenv("PKG_LIBS"="")
  rm(list=ls(all=TRUE))
}
