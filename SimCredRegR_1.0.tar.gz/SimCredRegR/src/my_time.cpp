//Author: Tobias Siems <tobias.siems@yahoo.com>
#include"my_time.h"
#include"declarations.h"



my_time::my_time(){
    start=std::time(NULL);
}

size_t my_time::time_since_start(bool give_time){
    size_t seconds=time(NULL)-start;
    if(give_time==true)
        std::cout<<"overall seconds: "<<seconds<<", minutes: "<<double(seconds)/60<<", hours: "<<double(seconds)/(60*60)<<std::endl;
    return seconds;
}



