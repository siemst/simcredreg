#ifndef GREEDY_H
#define GREEDY_H
#include"declarations.h"

class greedy{
public:
    greedy(csr data_size, csr number_of_alphas):data_size(data_size), number_of_alphas(number_of_alphas){}
    std::vector<indexlist> operator()(csr sample_size, const std::vector<indexvec> &samples);

private:
    csr data_size;
    csr number_of_alphas;

    void drop_samples(csr droped_timepoint, std::vector<index_unordered_set> &vertical_coverage, const std::vector<indexvec> &samples);
    void get_greedy_region(cdr alpha, csr sample_size, indexlist &region, const std::vector<std::pair<size_t, size_t>> &heuristic_solution);
};

#endif // GREEDY_H
